package com.iftm.client;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DsclientApplicationTests {

	@Test
	void contextLoads() {
	}

}
